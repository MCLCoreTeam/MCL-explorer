import Component from '../core/Component';
import React from 'react';

export default class Error404 extends Component {
  render() {
    return (
      <h1>Error 404</h1>
    );
  };
}
